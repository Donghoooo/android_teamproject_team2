package bitc.example.app.dto

import com.google.gson.annotations.SerializedName

data class BudgetDTO(
  @SerializedName("memberId")
  var memberId: String? = null,
  @SerializedName("b_24_1")
  var b_24_1: Int? = null,
  @SerializedName("b_24_2")
  var b_24_2: Int? = null,
  @SerializedName("b_24_3")
  var b_24_3: Int? = null,
  @SerializedName("b_24_4")
  var b_24_4: Int? = null,
  @SerializedName("b_24_5")
  var b_24_5: Int? = null,
  @SerializedName("b_24_6")
  var b_24_6: Int? = null,
  @SerializedName("b_24_7")
  var b_24_7: Int? = null,
  @SerializedName("b_24_8")
  var b_24_8: Int? = null,
  @SerializedName("b_24_9")
  var b_24_9: Int? = null,
  @SerializedName("b_24_10")
  var b_24_10: Int? = null,
  @SerializedName("b_24_11")
  var b_24_11: Int? = null,
  @SerializedName("b_24_12")
  var b_24_12: Int? = null,
  @SerializedName("b_25_1")
  var b_25_1: Int? = null,
  @SerializedName("b_25_2")
  var b_25_2: Int? = null,
  @SerializedName("b_25_3")
  var b_25_3: Int? = null,
  @SerializedName("b_25_4")
  var b_25_4: Int? = null,
  @SerializedName("b_25_5")
  var b_25_5: Int? = null,
  @SerializedName("b_25_6")
  var b_25_6: Int? = null,
  @SerializedName("b_25_7")
  var b_25_7: Int? = null,
  @SerializedName("b_25_8")
  var b_25_8: Int? = null,
  @SerializedName("b_25_9")
  var b_25_9: Int? = null,
  @SerializedName("b_25_10")
  var b_25_10: Int? = null,
  @SerializedName("b_25_11")
  var b_25_11: Int? = null,
  @SerializedName("b_25_12")
  var b_25_12: Int? = null,
  @SerializedName("b_26_1")
  var b_26_1: Int? = null,
  @SerializedName("b_26_2")
  var b_26_2: Int? = null,
  @SerializedName("b_26_3")
  var b_26_3: Int? = null,
  @SerializedName("b_26_4")
  var b_26_4: Int? = null,
  @SerializedName("b_26_5")
  var b_26_5: Int? = null,
  @SerializedName("b_26_6")
  var b_26_6: Int? = null,
  @SerializedName("b_26_7")
  var b_26_7: Int? = null,
  @SerializedName("b_26_8")
  var b_26_8: Int? = null,
  @SerializedName("b_26_9")
  var b_26_9: Int? = null,
  @SerializedName("b_26_10")
  var b_26_10: Int? = null,
  @SerializedName("b_26_11")
  var b_26_11: Int? = null,
  @SerializedName("b_26_12")
  var b_26_12: Int? = null
)
